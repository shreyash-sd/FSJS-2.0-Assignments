# FSJS VS Code Clone Project

**Made with Tailwind**




